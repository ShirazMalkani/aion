# retail store

How to execute:
1. Import as maven project in intelliJ or any other IDE
2. run maven clean install
3. execute main file in com.aion.retail.RetailApplication
4. Access Swagger at: http://localhost:8080/swagger-ui.html


Implementation details:
1. Api accepts userId and OrderItemIds as request body
2. Fetch user from the DB
3. Fetch OrderItems against the ids from the db
4. Calculate total amount of order items
5. Perform discount logic on the basis of the userType fetched from the db an on the total which was calculated
6. Returns an object with Total price, discount, and total price after discount
7. In-mem H2 - db is used
8. Data is feeded to the application at the runtime from a file of data.sql which can be found here resources > data.sql

