package com.aion.retail.controller;

import com.aion.retail.dto.OrderDto;
import com.aion.retail.service.DiscountService;
import com.aion.retail.service.OrderItemService;
import com.aion.retail.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/discount")
@RequiredArgsConstructor
public class DiscountController {
    private final DiscountService discountService;

    @PostMapping("/calculate")
    public Object calculateDiscount(@RequestBody @Valid OrderDto orderDto) {
        return discountService.calculateDiscount(orderDto);
    }
}
