package com.aion.retail.dto;

import lombok.Data;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class OrderDto {
    @NotNull(message = "Order should have userId")
    private Long userId;

    @NotNull(message = "OrderItems should not be null against an order")
    private List<Long> orderItems;
}
