package com.aion.retail.service;

import com.aion.retail.dto.DiscountDto;
import com.aion.retail.dto.OrderDto;
import com.aion.retail.entity.OrderItem;
import com.aion.retail.entity.User;
import com.aion.retail.repository.OrderItemRepository;
import com.aion.retail.repository.UserRepository;
import com.aion.retail.utils.DiscountUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static com.aion.retail.utils.DiscountUtil.calculateTotalPrice;

@Slf4j
@Service
@RequiredArgsConstructor
public class DiscountService {

    private final OrderItemRepository orderItemRepository;
    private final UserRepository userRepository;

    public DiscountDto calculateDiscount(OrderDto orderDto) {
        List<OrderItem> orderItems = orderItemRepository.findAllById(orderDto.getOrderItems());
        log.info("orderItems {}", orderItems);

        Optional<User> user = userRepository.findById(orderDto.getUserId());
        log.info("user {}", user.isPresent() ? user.get() : null);

        if(user.isEmpty()) {
            throw new RuntimeException("User not found");
        }

        Double totalPrice = calculateTotalPrice(orderItems);
        log.info("total amount {}", totalPrice);

        Double discountedAmount = DiscountUtil.calculateDiscount(totalPrice, user.get().getType());
        return DiscountDto
                .builder()
                .totalPrice(totalPrice)
                .discount(totalPrice - discountedAmount)
                .priceAfterDiscount(discountedAmount)
                .build();
    }

}
