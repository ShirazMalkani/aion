package com.aion.retail.service;

import com.aion.retail.entity.OrderItem;
import com.aion.retail.repository.OrderItemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class OrderItemService {
    private final OrderItemRepository orderItemRepository;

    public OrderItem getOrderItem() {
        return orderItemRepository.findAll().get(0);
    }
}
