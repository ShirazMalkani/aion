package com.aion.retail.service;

import com.aion.retail.entity.User;
import com.aion.retail.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public User getUser() {
        return userRepository.findAll().get(0);
    }

}
