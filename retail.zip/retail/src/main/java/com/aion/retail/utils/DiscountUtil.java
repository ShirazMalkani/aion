package com.aion.retail.utils;

import com.aion.retail.entity.OrderItem;

import java.util.List;

public class DiscountUtil {

    public static Double calculateTotalPrice(List<OrderItem> orderItems) {
        return orderItems.stream().mapToDouble(OrderItem::getPrice).sum();
    }

    public static Double calculateDiscount(Double totalPrice, String userType) {
        Double discountPercent = 0.0;
        switch (userType) {
            case "EMPLOYEE":
                discountPercent = 0.3;
                break;
            case "REGULAR":
                discountPercent = 0.1;
                break;
        }
        Double finalPrice = totalPrice - (totalPrice * discountPercent);
        Double over100Discount = totalPrice % 100 * 5;
        return finalPrice - over100Discount;
    }
}
