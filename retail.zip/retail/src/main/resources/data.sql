INSERT INTO users (id, name, type) VALUES (1, 'Ahsan', 'EMPLOYEE');
INSERT INTO users (id, name, type) VALUES (2, 'TAHA', 'REGULAR');


INSERT INTO order_item (id, name, price) VALUES (1, 'iWatch', 200);
INSERT INTO order_item (id, name, price) VALUES (2, 'iPhone', 600);
INSERT INTO order_item (id, name, price) VALUES (3, 'iPad', 500);